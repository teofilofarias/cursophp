<?php
    echo("Olá PHP!");
?>
